package com.smart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

import org.assertj.core.api.Assertions;
@SpringBootTest
class SmartContactManagerApplicationTests {

	private Calculator c=new Calculator();
	
	@Test
	void contextLoads() {
	}

	@Test
	void testSum() {
		
		int expectedResult=5;
		
		int actualResult = c.doSum(2, 3);
		
		assertThat(actualResult).isEqualTo(expectedResult);
		
		
	}
}
