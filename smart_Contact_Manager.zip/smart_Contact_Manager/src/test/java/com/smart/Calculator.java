package com.smart;

public class Calculator {

	public int doSum(int a,int b) {
		return a+b;
	}
	
	public int doProduct(int a ,int b) {
		return a*b;
	}
}
