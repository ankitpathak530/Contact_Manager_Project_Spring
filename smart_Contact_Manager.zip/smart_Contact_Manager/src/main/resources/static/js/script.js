/**
 * 
 */
 const toggleSidebar = () => {
        
         if($('.sidebar').is(":visible")){
         	//true
         	$(".sidebar").css("display","none");
         	$(".content").css("margin-left","2%");
         	$(".content").css("margin-top","5%");
         }
         else{
         	//false
         	 	$(".sidebar").css("display","block");
            	$(".content").css("margin-left","20%");
         }

 }; 
 
 const hideSidebar = () => {
	 if($('.sidebar').is(":visible")){
		   	$(".sidebar").css("display","none");
	  }
	  else{
		$(".sidebar").css("display","block");
	}
};



const search = () => {
   
   let query = document.getElementById("search-input").value;
  
   if(query == ""){
      $(".search-result").hide();
   }
   else{	   
   	  let url = `http://localhost:8080/search/${query}`;
       
       fetch(url)
          .then((response) => {
	           return response.json();
           })
           .then((data)=>{
	          // data is here
	           console.log(data);
	           let text = `<div class='list-group'>`
	               data.forEach((contact) =>{
		                 text+= `<a href='/user/contact/${contact.cId}' class='list-group-item list-group-action'> ${contact.name}     </a>` 
	                 });
	           text+= `</div>`;
	           $(".search-result").html(text);
	           $(".search-result").show(); 
           });
        
       $(".search-result").show();
            
   }
};


const paymentStart=()=>{
	
	let amount = $("#total_payment").val();
	if(amount == null || amount<=1 || amount==0.0){
	   swal("Error","Please donate at least 1Rs.","error");
		return;
	}
	// ajax to send request to server to create order
	
	$.ajax(
		{
			url:'/user/create_order',
			data:JSON.stringify({amount:amount,info:'order_request'}),
			contentType:'application/json',
			type:'POST',
			dataType:'json',
			success:function(response){
				//execute when success
				if(response.status == "created"){
					//open payment form
					let options={
						key:'rzp_test_EBqQQm0SrNzPft',
						amount:response.amount,
						currency:'INR',
						name:'Contact Manager Donation',
						image:'https://razorpay.com/assets/home/icon-paymentmodes.svg',
						order_id:response.id,
						handler:function(response){
							console.log(response.razorpay_payment_id);
							console.log(response.razorpay_order_id);
							console.log(response.razorpay_signature);
							console.log("payment success");
							swal("Thank you","Payment success","success");
						},
						"prefill": {
                             "name": "",
                             "email": "",
                             "contact": ""
                         },
                            "notes": {
                               "address": "contact manager payment"
                         },

					};	//options object done
					
					let rzp = new Razorpay(options);
					
					rzp.on('payment.failed', function (response){
					        console(response.error.code);
					        console(response.error.description);
					        console(response.error.source);
					        console(response.error.step);
					        console(response.error.reason);
					        console(response.error.metadata.order_id);
					        console(response.error.metadata.payment_id);
					        swal("Payment Failed","Try after some time","error");
                     });

					rzp.open();
					
					
					
				}
			},
			error:function(error){
				//execute when error
				  swal("Payment Failed","Try after some time","error");
			}
		}
	)
	
	
	
	
	
	
}





