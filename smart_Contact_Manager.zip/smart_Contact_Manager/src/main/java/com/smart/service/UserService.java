package com.smart.service;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.smart.dao.UserRepository;
import com.smart.model.Contact;
import com.smart.model.User;

@Service
public class UserService {

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@Autowired
	private UserRepository userRepository;
	

	
	
	
	
	
	public User doRegister(User user)
	{
		 
		  user.setRole("ROLE_USER");
		  user.setEnabled(true);
		  user.setPassword(bCryptPasswordEncoder.encode(user.getPassword()));
		  
		  User user1 = this.userRepository.save(user);
		  
		  return user1;
	}
	
	
	
	
	
	
	
	public User addCommonData(String userName)
	{
		return this.userRepository.getUserByUsername(userName);
	}
	
	
	
	
	
	
	
	
	
	//If everything is fine without exception return true else return false
	public boolean processContact(Contact contact,MultipartFile file,String userName)
	{
		boolean flag = false;
		
		try 
		{	
			User user = this.userRepository.getUserByUsername(userName);
			
			//uploading file
	    	if(!file.isEmpty())
	    	{
	    		contact.setImage(file.getOriginalFilename());
	    		
	    		File file1  = new ClassPathResource("static/img").getFile();
	    		Path path = Paths.get(file1.getAbsolutePath()+File.separator+file.getOriginalFilename());
	    		Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);
	    		
	           //image uploaded
	    	}
	    	else 
	    	{
	    		contact.setImage("default.png");
	    	}
	    	contact.setUser(user);
	    	user.getContacts().add(contact);
	    	this.userRepository.save(user);     //This line executed means everything is OK..
	    	
	    	flag = true;
		}
		catch(Exception e)
		{
			flag = false;
		}
		
		return flag;
	}
	
	
	
	
	
	
	
	
	public boolean updatePassword(String userName,String oldPassword, String newPassword)
	{
		   User user = this.userRepository.getUserByUsername(userName);
		    	
		   if(this.bCryptPasswordEncoder.matches(oldPassword, user.getPassword())) 
		   {
		    	    user.setPassword(this.bCryptPasswordEncoder.encode(newPassword));
		    	    this.userRepository.save(user);
		    	    return true;
		   }
		   else 
		   {
		    		return false;
		   }
	}
	
	
	
	
	
	
	
	
}
