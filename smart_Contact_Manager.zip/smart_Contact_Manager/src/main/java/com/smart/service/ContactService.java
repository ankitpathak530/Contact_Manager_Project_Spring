package com.smart.service;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.smart.dao.ContactRepository;
import com.smart.dao.UserRepository;
import com.smart.model.Contact;
import com.smart.model.User;

@Service
public class ContactService {

	

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private ContactRepository contactRepository;
	
	
	
	
	
	
	
	public Page<Contact> showContact(String userName,int page)
	{
         User user = this.userRepository.getUserByUsername(userName);
    	 Pageable pageable = PageRequest.of(page, 5); 
    	 Page<Contact> contacts = this.contactRepository.findContactsByUser(user.getId(),pageable);
    	 
    	 return contacts;
	}
	
	
	
	
	
	
	public Contact showContactDetail(String userName,int cId)
	{
		 try
		 {
		    	Contact contact = this.contactRepository.findContactByUserId(cId);
		    	User     user =  this.userRepository.getUserByUsername(userName);
		    	
		    	//Check for only Authorized contact to show not any other's
		    	if(user.getId() == contact.getUser().getId())
		    	    return contact;
		    	
		 }catch(Exception e) {
		       e.printStackTrace();
		  }
		 return null;
	}
	
	
	
	
	
	
	
	
	public void deleteContactDetail(String userName, Integer cId)
	{
		System.out.println("-------------------------i am                      "+userName);
		 User user = this.userRepository.getUserByUsername(userName);
    	 Contact contact = this.contactRepository.findById(cId).get();
    	
    	 //Check for Authorized contact to delete not any other's
    	 if(contact.getUser().getId() == user.getId()) {
    		 contact.setUser(null);
    		 this.contactRepository.deleteById(cId);
    		 
    		 String image_name = contact.getImage();
    		 
    		 try {
    			if(!image_name.equals("default.png")) {
					File f1 = new ClassPathResource("static/img").getFile();
					Path path = Paths.get(f1.getAbsolutePath()+File.separator+image_name);
					Files.delete(path);
    			}
			} catch (Exception e) {
				e.printStackTrace();
			}	 
    	 }
	}
	
	
	
	
	
	
	
	
	public Contact updateForm(int cId)
	{
		Contact contact = this.contactRepository.findContactByUserId(cId);
		
		return contact;
	}
	
	
	
	
	
	
	public void updateHandler(Contact contact,String userName,int cId,MultipartFile file)
	{
		
		try
			{		    	
		    	User user = this.userRepository.getUserByUsername(userName);
		    	Contact c = this.contactRepository.findContactByUserId(cId);
		    	  	
		    	if(file.isEmpty() && c.getName().equals("default.png"));
		    		contact.setImage("default.png");
		    	
		    	if(!file.getOriginalFilename().isEmpty()) {
		    		                                                 //delete previous image
		    		String oldImage = c.getImage();
		    		
		    		if(!oldImage.equals("default.png")) 
		    		{		    		
		    	         File file2 = new ClassPathResource("static/img").getFile();
		    	         Path path = Paths.get(file2.getAbsolutePath()+File.separator+oldImage);
		    	         Files.delete(path);
		    		}
		   
		    		                                               //Add new image
		    		String newImage = file.getOriginalFilename();
		    		File file3 = new ClassPathResource("static/img").getFile();
		    		Path path2 = Paths.get(file3.getAbsolutePath()+File.separator+newImage);
		    		Files.copy(file.getInputStream(),path2,StandardCopyOption.REPLACE_EXISTING);
		    		
		    		contact.setImage(newImage);
		    		
		    	}
		    	contact.setcId(cId);
		    	contact.setUser(user);
		    	
		    	this.contactRepository.save(contact);
	     }
		catch(Exception ex){
	    	ex.printStackTrace();
		}
		
	 }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
