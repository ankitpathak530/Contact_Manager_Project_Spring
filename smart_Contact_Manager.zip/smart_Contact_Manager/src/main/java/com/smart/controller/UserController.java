package com.smart.controller;



import java.security.Principal;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.smart.helper.Message;
import com.smart.model.Contact;
import com.smart.model.User;
import com.smart.service.ContactService;
import com.smart.service.UserService;
import com.razorpay.*;

@Controller
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService userService;
	
	@Autowired
	private ContactService contactService;
	

	
	
	
	
	
	
    //method for adding common data to all 
	@ModelAttribute
	public void addCommonData(Model model,Principal principal) 
	{

		String userName = principal.getName();
		
		User user = this.userService.addCommonData(userName);
		
		model.addAttribute("user",user);
	}
	
	
	//Dashboard home
	@RequestMapping("/index")
	 public String dashboard(Model model,Principal principal) 
	 {
	    model.addAttribute("title","Add Contact");
		return "normal/user_dashboard";
	 }
	 
	
	
	
	
   @GetMapping("/add-contact")
	public String openAddContactForm(Model model) 
    {
	   
	    model.addAttribute("title","Add Contact");
	    model.addAttribute("contact",new Contact());

		return "normal/add_contact_form";
	}
	 
   
   
   
   
   
   //processing add contact form
    @PostMapping("/process-contact")
    public String processContact(@ModelAttribute Contact contact,Model model,
       @RequestParam("img") MultipartFile file,Principal principal)
    {
    	    String userName = principal.getName();
    	    boolean result = this.userService.processContact(contact, file,userName);
    		if(result)
    		{
    			 model.addAttribute("result","success");
    		}
    		else
    		{
    			 model.addAttribute("result","error");
    		}
    
    	return "normal/add_contact_form";
    }
	
    
    
    
	
    //show contact handler
    // I have to show 5 item per page applying pagination
    
    @GetMapping("/show-contacts/{page}")
    public String showContact(Model model,Principal principal,@PathVariable("page") int page)
    {
        String userName = principal.getName();
    	
        Page<Contact> contacts = this.contactService.showContact(userName,page);
    
    	model.addAttribute("contacts",contacts);
    	model.addAttribute("currentPage",page);
    	model.addAttribute("totalPages",contacts.getTotalPages());
    	
        return "normal/show_contacts";
    }
	
    
    
    
    
    
    
    //showing particular contact
    @RequestMapping("/contact/{cId}")
     public String showContactDetail(@PathVariable("cId")Integer cId,Model m,Principal principal)
    {
        String userName = principal.getName();
        
        Contact contact = this.contactService.showContactDetail(userName,cId);
        if(contact != null)
        {
        	m.addAttribute("contact",contact);
        }

       return "normal/contact-detail";
     }
    
    
    
    
    
    
    @PostMapping("/delete/{cId}")
    public String deleteContactDetail(@PathVariable("cId")Integer cId,Principal principal)
    {
    	String userName = principal.getName();
    	
    	this.contactService.deleteContactDetail(userName,cId);
    
    	return "redirect:/user/show-contacts/0";
    }
    
    
    
    
    
    
    
    @PostMapping("/update-contact/{cid}")
    public String updateForm(@PathVariable("cid")int cId,Model m) 
    {
    	Contact contact = this.contactService.updateForm(cId);
    	 
    	m.addAttribute("c",contact);
    	
    	return "normal/update-contact";
    }
    
    
    
    
    
    
    
    
    @PostMapping("/process-update/{cId}")
    public String updateHandler(@ModelAttribute Contact contact,@PathVariable("cId")int cId,Principal principal,@RequestParam("img") MultipartFile file)
    {
    	System.out.println("update handler working.......................................");
    	String userName = principal.getName();
    	
    	this.contactService.updateHandler(contact,userName,cId,file);
    	
    	return "redirect:/user/contact/"+contact.getcId();
    }
  
    
    
    
    
    
    @GetMapping("/profile-detail")
    public String profileDetail()
    {
    	return "normal/profile-detail";
    }
    
    
    
    @GetMapping("/seting")
    public String seting()
    {
    	return "normal/seting";
    }
    
    
    
    
    
    @PostMapping("/updatePassword")
    public String updatePassword(@RequestParam("oldpassword") String oldPassword,@RequestParam("password1") String newPassword,Principal principal,HttpSession session)
    {
    	String uName = principal.getName();
    	
    	boolean result = this.userService.updatePassword(uName,oldPassword,newPassword);
    	if(result)
    	{
    		  session.setAttribute("message",new Message(" password  changed","alert-success"));
    	}
    	else
    	{
    		session.setAttribute("message", new Message("Password not changed","alert-danger"));
    		return "redirect:/user/seting";
    	}
    	return "redirect:/user/index";
    }

    
    
    
    
    
    @PostMapping("/create_order")
    @ResponseBody
    public String createOrder(@RequestBody Map<String,Object> data) {
    	
    	System.out.println("order genereated");
    	int amount = Integer.parseInt(data.get("amount").toString());
    	
    	
    	 try {
			var client = new RazorpayClient("rzp_test_EBqQQm0SrNzPft", "soew7vVSeWR4h5bJWo5VpeKY");
		    
    	    JSONObject ob = new JSONObject();
			ob.put("amount", amount*100);
			ob.put("currency","INR");
			ob.put("receipt", "TXn134343");
			
			
			//creating new order
			
			Order order = client.Orders.create(ob);
			System.out.println("order created--->"+order);
			
			
			//Save this order to database important;
			
			
			return order.toString();
    	 
    	 } catch (RazorpayException e) {
			e.printStackTrace();
		}
    	
    	
    	
    	
    	
    	return "order not created"; 		
    }
    
    
    
    
}
