package com.smart.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.smart.model.User;
import com.smart.service.UserService;


@Controller
public class HomeController {
	
	@Autowired
	private UserService userService;
	
	@RequestMapping("/home")
	public String test() {
		return "index";
	}
	
	@RequestMapping("/about")
	public String about() {
		return "about";
	}
	
	@RequestMapping("/signin")
	public String login() {
		return "login";
	}
	
	@RequestMapping("/signup")
	public String signup(Model m) {	
		m.addAttribute("user",new User());	
		return "signup";
	}
	
	
	
	
	@RequestMapping(value="/do_register",method = RequestMethod.POST)
	public String doRegister(@Valid @ModelAttribute("user") User user,BindingResult result, Model model)
	{
		
		  if(result.hasErrors())
		  {
			  System.out.println("Sign up failed,Something went wrong ");
			  model.addAttribute("result","error");
		  }
		  else
		  {
			  User userResult =  this.userService.doRegister(user);
				 
			  if(userResult != null)
			  {
				  model.addAttribute("result","success");
			  }
			  else
			  {
				  model.addAttribute("result","error");
			  }
		  }
		  
		return "signup";
	}
	
	
	
	
	
	
	
}
