package com.smart.controller;


import java.util.Random;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.smart.dao.UserRepository;
import com.smart.helper.Message;
import com.smart.model.User;
import com.smart.service.EmailService;

@Controller
public class ForgetController {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private EmailService emailService;
	
	@Autowired
	private BCryptPasswordEncoder bcryptPasswordEncoder;
	
	
	
	
	
	
	
    Random random = new Random(100000);
	
	 @GetMapping("/forget")
	  public String openEmailForm() {
		  return "forget_email_form";
	  }
	 
	 
	 @PostMapping("/send_otp")
	 public String sendOTOP(@RequestParam("email") String email,HttpSession session) {
		 		 
		 if(this.userRepository.getUserByUsername(email) != null)
		 {
		    //Generating 6 Digit OTP

			 int otp = random.nextInt(999999);
			 session.setAttribute("old_otp", otp);
			 session.setAttribute("email", email);
			 
			 String subject = "OTP verfication from Smart Contact Manager";
			 String message = ""
			                + "<div style='border:2px solid #e2e2e2;padding:30px;'>"  
					        + "<h1>"
			                +"Your secret OTP is "
					        +"<b>"+otp
					        +"</b>"
					        +"</h1>"
			                +"</div>";
					
			 if(this.emailService.sendEmail(subject, message, email))
				 return "verify_otp";
		 }		 
	     session.setAttribute("message", "Your email id is not verified with us.");
		 return "forget_email_form"; 
	   
	 }
	 
	 @PostMapping("/verify_otp")
	 public String verify_otp(@RequestParam("otp") int new_otp,HttpSession session) {
		 
		 int old_otp = (int) session.getAttribute("old_otp");  
				
		 if(new_otp == old_otp) {
			 return "password_change_form";
		 }
		 else {
			 session.setAttribute("message","You have entered wrong OTP");
			 return "verify_otp";
		 }
		 
	 }
	 
	 @PostMapping("/updatePassword")
	 public String update_password(@RequestParam("password1")String password1,@RequestParam("password2") String password2,HttpSession session) {
		
		 if(!password1.equals(password2)) {
			 session.setAttribute("message2","Confirm Password did not match");
		    return "password_change_form";	 
		 }
		 String username = (String)session.getAttribute("email");
		 User user = this.userRepository.getUserByUsername(username);
		 user.setPassword(this.bcryptPasswordEncoder.encode(password2));
		 this.userRepository.save(user); 
		 
		 session.setAttribute("message",new Message(" password  changed","alert-success"));
		 
		 return "redirect:/user/index";
	 }
	 
	 
}
