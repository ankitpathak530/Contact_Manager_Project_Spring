package com.smart.dao;


import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


import com.smart.model.User;
public interface UserRepository extends JpaRepository<User,Integer>{


	 @Query("select u from User u where u.email = :email")
	 public User getUserByUsername(@Param("email")String username);

//	 @Query("select u from User u where u.schoolEmail=:c and u.schoolPassword=:p")
//	 public User getUserByUsernamePassword(@Param("c")String username,@Param("p")String password);
 
}
